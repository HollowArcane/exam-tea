<?php
    include('function/function.php');
    $co = dbConnect();
    $mail = "rambao@gmail.com";
    $mdp = "rambao";
    $id = 3;
    $surface = 20;
    $variete = 3;
    $res = updateParcelle($co, $id, $surface, $variete);
    
    var_dump($res);
?>